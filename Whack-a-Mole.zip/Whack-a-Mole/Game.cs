﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Whack_a_Mole
{
    public partial class Game : Form
    {
        int g = 0;
        int doesnot = 0;
        int score = 0;

        public Game()
        {
            InitializeComponent();
        }

        void Change(Button btn)
        {
            btn.BackColor = Color.Red;
        }

        void Reset(Button btn)
        {
            btn.BackColor = Color.Black;
        }

        private void tmrGame_Tick(object sender, EventArgs e)
        {
            lblMissed.Text = doesnot.ToString() + " : Missed";
            lblScore.Text = "Score : " + score.ToString();
            Random r = new Random();
            g = r.Next(0, 7);

            switch (g)
            {
                case 1:
                    Change(A1);
                    break;
                case 2:
                    Change(A2);
                    break;
                case 3:
                    Change(A3);
                    break;
                case 4:
                    Change(B1);
                    break;
                case 5:
                    Change(B2);
                    break;
                case 6:
                    Change(B3);
                    break;
            }
            doesnot++;

            if(doesnot == 5)
            {
                tmrGame.Stop();
                MessageBox.Show("Your highscore was : " + score);
            }
        }

        private void A1_Click(object sender, EventArgs e)
        {
            Reset(A1);
            doesnot--;
            score++;
        }

        private void A2_Click(object sender, EventArgs e)
        {
            Reset(A2);
            doesnot--;
            score++;
        }

        private void A3_Click(object sender, EventArgs e)
        {
            Reset(A3);
            doesnot--;
            score++;
        }

        private void B1_Click(object sender, EventArgs e)
        {
            Reset(B1);
            doesnot--;
            score++;
        }

        private void B2_Click(object sender, EventArgs e)
        {
            Reset(B2);
            doesnot--;
            score++;
        }

        private void B3_Click(object sender, EventArgs e)
        {
            Reset(B3);
            doesnot--;
            score++;
        }

        private void Game_Load(object sender, EventArgs e)
        {
            tmrGame.Start();
        }
    }
}
