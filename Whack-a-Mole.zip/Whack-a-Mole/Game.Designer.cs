﻿namespace Whack_a_Mole
{
    partial class Game
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.A1 = new System.Windows.Forms.Button();
            this.A2 = new System.Windows.Forms.Button();
            this.A3 = new System.Windows.Forms.Button();
            this.B3 = new System.Windows.Forms.Button();
            this.B2 = new System.Windows.Forms.Button();
            this.B1 = new System.Windows.Forms.Button();
            this.tmrGame = new System.Windows.Forms.Timer(this.components);
            this.tmrCheck = new System.Windows.Forms.Timer(this.components);
            this.lblScore = new System.Windows.Forms.Label();
            this.lblMissed = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // A1
            // 
            this.A1.BackColor = System.Drawing.Color.Black;
            this.A1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.A1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.A1.Location = new System.Drawing.Point(44, 102);
            this.A1.Name = "A1";
            this.A1.Size = new System.Drawing.Size(105, 93);
            this.A1.TabIndex = 0;
            this.A1.UseVisualStyleBackColor = false;
            this.A1.Click += new System.EventHandler(this.A1_Click);
            // 
            // A2
            // 
            this.A2.BackColor = System.Drawing.Color.Black;
            this.A2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.A2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.A2.Location = new System.Drawing.Point(192, 102);
            this.A2.Name = "A2";
            this.A2.Size = new System.Drawing.Size(105, 93);
            this.A2.TabIndex = 1;
            this.A2.UseVisualStyleBackColor = false;
            this.A2.Click += new System.EventHandler(this.A2_Click);
            // 
            // A3
            // 
            this.A3.BackColor = System.Drawing.Color.Black;
            this.A3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.A3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.A3.Location = new System.Drawing.Point(341, 102);
            this.A3.Name = "A3";
            this.A3.Size = new System.Drawing.Size(105, 93);
            this.A3.TabIndex = 2;
            this.A3.UseVisualStyleBackColor = false;
            this.A3.Click += new System.EventHandler(this.A3_Click);
            // 
            // B3
            // 
            this.B3.BackColor = System.Drawing.Color.Black;
            this.B3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.B3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.B3.Location = new System.Drawing.Point(341, 236);
            this.B3.Name = "B3";
            this.B3.Size = new System.Drawing.Size(105, 93);
            this.B3.TabIndex = 5;
            this.B3.UseVisualStyleBackColor = false;
            this.B3.Click += new System.EventHandler(this.B3_Click);
            // 
            // B2
            // 
            this.B2.BackColor = System.Drawing.Color.Black;
            this.B2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.B2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.B2.Location = new System.Drawing.Point(192, 236);
            this.B2.Name = "B2";
            this.B2.Size = new System.Drawing.Size(105, 93);
            this.B2.TabIndex = 4;
            this.B2.UseVisualStyleBackColor = false;
            this.B2.Click += new System.EventHandler(this.B2_Click);
            // 
            // B1
            // 
            this.B1.BackColor = System.Drawing.Color.Black;
            this.B1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.B1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.B1.Location = new System.Drawing.Point(44, 236);
            this.B1.Name = "B1";
            this.B1.Size = new System.Drawing.Size(105, 93);
            this.B1.TabIndex = 3;
            this.B1.UseVisualStyleBackColor = false;
            this.B1.Click += new System.EventHandler(this.B1_Click);
            // 
            // tmrGame
            // 
            this.tmrGame.Interval = 500;
            this.tmrGame.Tick += new System.EventHandler(this.tmrGame_Tick);
            // 
            // tmrCheck
            // 
            this.tmrCheck.Interval = 1;
            // 
            // lblScore
            // 
            this.lblScore.AutoSize = true;
            this.lblScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblScore.Location = new System.Drawing.Point(40, 27);
            this.lblScore.Name = "lblScore";
            this.lblScore.Size = new System.Drawing.Size(80, 25);
            this.lblScore.TabIndex = 6;
            this.lblScore.Text = "Score : ";
            // 
            // lblMissed
            // 
            this.lblMissed.AutoSize = true;
            this.lblMissed.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMissed.Location = new System.Drawing.Point(375, 27);
            this.lblMissed.Name = "lblMissed";
            this.lblMissed.Size = new System.Drawing.Size(91, 25);
            this.lblMissed.TabIndex = 7;
            this.lblMissed.Text = " : Missed";
            // 
            // Game
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(506, 376);
            this.Controls.Add(this.lblMissed);
            this.Controls.Add(this.lblScore);
            this.Controls.Add(this.B3);
            this.Controls.Add(this.B2);
            this.Controls.Add(this.B1);
            this.Controls.Add(this.A3);
            this.Controls.Add(this.A2);
            this.Controls.Add(this.A1);
            this.Name = "Game";
            this.Text = "Whack a Mole";
            this.Load += new System.EventHandler(this.Game_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button A1;
        private System.Windows.Forms.Button A2;
        private System.Windows.Forms.Button A3;
        private System.Windows.Forms.Button B3;
        private System.Windows.Forms.Button B2;
        private System.Windows.Forms.Button B1;
        private System.Windows.Forms.Timer tmrGame;
        private System.Windows.Forms.Timer tmrCheck;
        private System.Windows.Forms.Label lblScore;
        private System.Windows.Forms.Label lblMissed;
    }
}

